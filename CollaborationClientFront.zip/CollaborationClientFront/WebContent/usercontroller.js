'use strict'
console.log("start of home controller")
                 
                	 

                		app.controller('AboutController', function($scope) {
                		  $scope.message = 'Hello from AboutController';
                		});  
                	  
		
		
                		app.controller('HomeController', function($scope) {
                  		  $scope.message = 'Hello from HomeController';
                  		});  
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		/*function($scope) {
	  $scope.message = 'Hello from HomeController';
	});

	app.controller('BlogController', function($scope) {
	  $scope.message = 'Hello from BlogController';
	});

	app.controller('AboutController', function($scope) {
	  $scope.message = 'Hello from AboutController';
	});
*//**
 * 
 */